const http = require('http');
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const url = require('url');
const querystring = require('querystring');

// Load data files into memory. We will also persist changes when users or properties are added.
let properties = [];
let users = [];
const sessions = {}; // sessionToken => userId

function loadData() {
  try {
    const propData = fs.readFileSync(path.join(__dirname, 'data', 'properties.json'), 'utf-8');
    properties = JSON.parse(propData);
  } catch (err) {
    console.error('Error loading properties:', err);
    properties = [];
  }
  try {
    const userData = fs.readFileSync(path.join(__dirname, 'data', 'users.json'), 'utf-8');
    users = JSON.parse(userData);
  } catch (err) {
    console.error('Error loading users:', err);
    users = [];
  }
}

function saveUsers() {
  fs.writeFileSync(path.join(__dirname, 'data', 'users.json'), JSON.stringify(users, null, 2));
}

function saveProperties() {
  fs.writeFileSync(path.join(__dirname, 'data', 'properties.json'), JSON.stringify(properties, null, 2));
}

// Simple templating: read file and replace {{placeholders}} with provided values.
function renderTemplate(templatePath, replacements) {
  let content = fs.readFileSync(templatePath, 'utf-8');
  for (const key in replacements) {
    const value = replacements[key];
    const regex = new RegExp('{{' + key + '}}', 'g');
    content = content.replace(regex, value);
  }
  return content;
}

// Utility: hash passwords using SHA256
function hashPassword(password) {
  return crypto.createHash('sha256').update(password).digest('hex');
}

// Create a random session token
function createSession(userId) {
  const token = crypto.randomBytes(16).toString('hex');
  sessions[token] = userId;
  return token;
}

// Parse cookies from request headers
function parseCookies(req) {
  const list = {};
  const cookieHeader = req.headers.cookie;
  if (!cookieHeader) return list;
  cookieHeader.split(';').forEach(cookie => {
    const parts = cookie.split('=');
    list[parts[0].trim()] = decodeURIComponent(parts[1]);
  });
  return list;
}

// Serve static files from public folder
function serveStatic(req, res, pathname) {
  const filePath = path.join(__dirname, 'public', pathname);
  if (!filePath.startsWith(path.join(__dirname, 'public'))) {
    res.writeHead(403);
    return res.end('Forbidden');
  }
  fs.readFile(filePath, (err, data) => {
    if (err) {
      res.writeHead(404);
      return res.end('Not Found');
    }
    const ext = path.extname(filePath).toLowerCase();
    const mimeTypes = {
      '.css': 'text/css',
      '.js': 'text/javascript',
      '.png': 'image/png',
      '.jpg': 'image/jpeg',
      '.jpeg': 'image/jpeg',
      '.webp': 'image/webp',
      '.svg': 'image/svg+xml'
    };
    res.writeHead(200, { 'Content-Type': mimeTypes[ext] || 'application/octet-stream' });
    res.end(data);
  });
}

// Build HTML for property cards
function buildPropertyCards(propertyList) {
  return propertyList.map(p => {
    const img = p.images && p.images.length > 0 ? p.images[0] : 'placeholder.png';
    return `
      <div class="property-card">
        <img src="/images/${img}" alt="${p.title}">
        <div class="details">
          <h3>${p.title}</h3>
          <p><strong>Location:</strong> ${p.location}</p>
          <p><strong>Price:</strong> ₹${p.price}</p>
          <p><strong>Type:</strong> ${p.type}</p>
          <a href="/property?id=${p.id}">View Details</a>
        </div>
      </div>
    `;
  }).join('\n');
}

// Helper: decode POST body
function parseRequestBody(req, callback) {
  let body = '';
  req.on('data', chunk => {
    body += chunk;
    if (body.length > 1e6) req.connection.destroy();
  });
  req.on('end', () => {
    callback(querystring.parse(body));
  });
}

// Create HTTP server
loadData();
const server = http.createServer((req, res) => {
  const parsedUrl = url.parse(req.url, true);
  const pathname = parsedUrl.pathname;
  const method = req.method;

  // Serve static assets
  if (pathname.startsWith('/css/') || pathname.startsWith('/js/') || pathname.startsWith('/images/')) {
    return serveStatic(req, res, pathname);
  }

  // Parse cookies and current user
  const cookies = parseCookies(req);
  const token = cookies.session;
  let currentUser = null;
  if (token && sessions[token]) {
    const userId = sessions[token];
    currentUser = users.find(u => u.id === userId);
  }

  // Routing
  if (pathname === '/' && method === 'GET') {
    // Home page: show latest 3 properties
    const latest = properties.slice(-3).reverse();
    const cards = buildPropertyCards(latest);
    const html = renderTemplate(path.join(__dirname, 'views', 'home.html'), {
      title: 'Landbloom Real Estate - Home',
      propertyCards: cards
    });
    res.writeHead(200, { 'Content-Type': 'text/html' });
    return res.end(html);
  }

  if (pathname === '/properties' && method === 'GET') {
    // Filter based on query
    let { q, type } = parsedUrl.query;
    let filtered = properties;
    if (q && q.trim() !== '') {
      const term = q.trim().toLowerCase();
      filtered = filtered.filter(p => (p.title.toLowerCase().includes(term) || p.location.toLowerCase().includes(term) || p.type.toLowerCase().includes(term)));
    }
    if (type && type !== '') {
      filtered = filtered.filter(p => p.type === type);
    }
    const cards = buildPropertyCards(filtered);
    const html = renderTemplate(path.join(__dirname, 'views', 'property-list.html'), {
      title: 'Landbloom Real Estate - Properties',
      propertyCards: cards || '<p>No properties found.</p>',
      query: q ? q : '',
      typeResidential: type === 'Residential' ? 'selected' : '',
      typeCommercial: type === 'Commercial' ? 'selected' : '',
      typeLand: type === 'Land' ? 'selected' : ''
    });
    res.writeHead(200, { 'Content-Type': 'text/html' });
    return res.end(html);
  }

  if (pathname === '/property' && method === 'GET') {
    const id = parseInt(parsedUrl.query.id);
    const property = properties.find(p => p.id === id);
    if (!property) {
      res.writeHead(404, { 'Content-Type': 'text/plain' });
      return res.end('Property not found');
    }
    const amenities = property.amenities && property.amenities.length > 0 ? property.amenities.join(', ') : 'None';
    const image = (property.images && property.images.length > 0) ? property.images[0] : 'placeholder.png';
    const html = renderTemplate(path.join(__dirname, 'views', 'property-detail.html'), {
      title: `Property Details - ${property.title}`,
      property: JSON.stringify(property), // not used but we might embed if needed
      amenities: amenities,
      image: image,
      'property.title': property.title,
      'property.location': property.location,
      'property.price': property.price,
      'property.type': property.type,
      'property.size': property.size,
      'property.description': property.description,
      'property.id': property.id
    });
    res.writeHead(200, { 'Content-Type': 'text/html' });
    return res.end(html);
  }

  if (pathname === '/login') {
    if (method === 'GET') {
      const html = renderTemplate(path.join(__dirname, 'views', 'login.html'), {
        title: 'Login',
        error: ''
      });
      res.writeHead(200, { 'Content-Type': 'text/html' });
      return res.end(html);
    }
    if (method === 'POST') {
      parseRequestBody(req, body => {
        const { username, password } = body;
        const user = users.find(u => u.username === username);
        if (!user || user.password !== hashPassword(password)) {
          const html = renderTemplate(path.join(__dirname, 'views', 'login.html'), {
            title: 'Login',
            error: '<p class="error">Invalid username or password</p>'
          });
          res.writeHead(401, { 'Content-Type': 'text/html' });
          return res.end(html);
        }
        const sessionToken = createSession(user.id);
        res.writeHead(302, {
          'Set-Cookie': `session=${sessionToken}; HttpOnly; Path=/`,
          'Location': '/dashboard'
        });
        return res.end();
      });
    }
    return;
  }

  if (pathname === '/register') {
    if (method === 'GET') {
      const html = renderTemplate(path.join(__dirname, 'views', 'register.html'), {
        title: 'Register',
        error: ''
      });
      res.writeHead(200, { 'Content-Type': 'text/html' });
      return res.end(html);
    }
    if (method === 'POST') {
      parseRequestBody(req, body => {
        const { username, name, role, password } = body;
        if (!username || !name || !role || !password) {
          const html = renderTemplate(path.join(__dirname, 'views', 'register.html'), {
            title: 'Register',
            error: '<p class="error">All fields are required.</p>'
          });
          res.writeHead(400, { 'Content-Type': 'text/html' });
          return res.end(html);
        }
        if (users.find(u => u.username === username)) {
          const html = renderTemplate(path.join(__dirname, 'views', 'register.html'), {
            title: 'Register',
            error: '<p class="error">Username already exists.</p>'
          });
          res.writeHead(400, { 'Content-Type': 'text/html' });
          return res.end(html);
        }
        const newUser = {
          id: users.length > 0 ? users[users.length - 1].id + 1 : 1,
          username,
          name,
          role,
          password: hashPassword(password)
        };
        users.push(newUser);
        saveUsers();
        res.writeHead(302, { 'Location': '/login' });
        return res.end();
      });
    }
    return;
  }

  if (pathname === '/dashboard' && method === 'GET') {
    if (!currentUser) {
      res.writeHead(302, { 'Location': '/login' });
      return res.end();
    }
    let content = '';
    if (currentUser.role === 'admin') {
      content += '<p><a href="/admin">Go to Admin Panel</a></p>';
    }
    const html = renderTemplate(path.join(__dirname, 'views', 'dashboard.html'), {
      title: 'Dashboard',
      'user.name': currentUser.name,
      'user.role': currentUser.role,
      user: JSON.stringify(currentUser),
      content: content
    });
    res.writeHead(200, { 'Content-Type': 'text/html' });
    return res.end(html);
  }

  if (pathname === '/admin') {
    if (!currentUser || currentUser.role !== 'admin') {
      res.writeHead(403, { 'Content-Type': 'text/plain' });
      return res.end('Access denied');
    }
    if (method === 'GET') {
      const html = renderTemplate(path.join(__dirname, 'views', 'admin.html'), {
        title: 'Admin Panel',
        message: ''
      });
      res.writeHead(200, { 'Content-Type': 'text/html' });
      return res.end(html);
    }
    if (method === 'POST' && pathname === '/admin/add') {
      // Actually handled below in specific route, but we keep here for clarity
    }
  }

  if (pathname === '/admin/add' && method === 'POST') {
    // Only admin can add property
    if (!currentUser || currentUser.role !== 'admin') {
      res.writeHead(403, { 'Content-Type': 'text/plain' });
      return res.end('Access denied');
    }
    parseRequestBody(req, body => {
      const { title, location, price, type, size, amenities, image, description } = body;
      if (!title || !location || !price || !type || !size || !description) {
        const html = renderTemplate(path.join(__dirname, 'views', 'admin.html'), {
          title: 'Admin Panel',
          message: '<p class="error">All fields except image/amenities are required.</p>'
        });
        res.writeHead(400, { 'Content-Type': 'text/html' });
        return res.end(html);
      }
      const newId = properties.length > 0 ? properties[properties.length - 1].id + 1 : 1;
      const newProperty = {
        id: newId,
        title,
        location,
        price: parseInt(price),
        type,
        size: parseInt(size),
        amenities: amenities ? amenities.split(',').map(a => a.trim()).filter(Boolean) : [],
        images: image ? [image.trim()] : [],
        description
      };
      properties.push(newProperty);
      saveProperties();
      const html = renderTemplate(path.join(__dirname, 'views', 'admin.html'), {
        title: 'Admin Panel',
        message: '<p style="color:green">Property added successfully!</p>'
      });
      res.writeHead(200, { 'Content-Type': 'text/html' });
      return res.end(html);
    });
    return;
  }

  if (pathname === '/logout') {
    if (token) {
      delete sessions[token];
    }
    res.writeHead(302, {
      'Set-Cookie': 'session=; Expires=Thu, 01 Jan 1970 00:00:00 GMT; Path=/',
      'Location': '/login'
    });
    return res.end();
  }

  // Simple booking page for property enquiries
  if (pathname === '/book' && method === 'GET') {
    const id = parseInt(parsedUrl.query.id);
    const property = properties.find(p => p.id === id);
    if (!property) {
      res.writeHead(404, { 'Content-Type': 'text/plain' });
      return res.end('Property not found');
    }
    let html = `<!DOCTYPE html><html><head><meta charset="utf-8"><title>Request Visit - ${property.title}</title><link rel="stylesheet" href="/css/style.css"></head><body>`;
    html += `<header><h1>Landbloom Real Estate</h1></header>`;
    html += `<div class="container"><h2>Request a visit for ${property.title}</h2>`;
    html += `<p>Please contact us at <strong>support@landbloom.com</strong> or call <strong>1800-000-000</strong> to schedule a viewing.</p>`;
    html += `<p><a href="/property?id=${property.id}">Back to Property</a></p></div>`;
    html += `<footer>&copy; 2025 Landbloom Real Estate &amp; Rentals Pvt Ltd. All rights reserved.</footer>`;
    html += `</body></html>`;
    res.writeHead(200, { 'Content-Type': 'text/html' });
    return res.end(html);
  }

  // Default: 404
  res.writeHead(404, { 'Content-Type': 'text/plain' });
  res.end('Page not found');
});

const PORT = 3000;
server.listen(PORT, () => {
  console.log(`Server running at http://localhost:${PORT}`);
});